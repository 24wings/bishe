using System;
namespace Wings.Base.Common.DTO
{

    /// <summary>
    /// DevExtream Body Datas
    /// </summary>
    public class DevExtreamQuery
    {
        /// <summary>
        /// 
        /// </summary>
        public string values { get; set; }
        /// <summary>
        /// 主键
        /// </summary>
        /// <value></value>
        public string key { get; set; }
    }
}